  Way2SMS API <br>
  ================
  * @Find more script like this at http://www.howi.in
  * You can easly edit the code by reading the comments made inside the code.
 <br>Find installation tutorail from : http://www.howi.in/2015/07/way2sms-working-api-php-script.html


<!-- 
	* @source code designed by Muhsin Mohamed Pc for http://www.howi.in
	* Report bugs and errors to waphunt@gmail.com
	* @This script was coded with the help of many other github projects. I thanks to them
	* @Take backup before editing the script
-->
</div>
<footer class="w3-container w3-red">
  <h3>Powered By : <a href="google.com">H&K Securities<a/></h3>
</footer>
<!-- 
	* @source code designed by Muhsin Mohamed Pc for http://www.howi.in
	* Report bugs and errors to waphunt@gmail.com
	* @This script was coded with the help of many other github projects. I thanks to them
	* @Take backup before editing the script
-->